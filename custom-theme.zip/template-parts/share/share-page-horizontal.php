<div class="d-inline-block bg-white p-20 position-relative rounded-pill js__share-page">
    <a class="w-50 h-50 lh-50 rounded-circle float-left text-black hover:bg-gray-100 share-page__on-facebook"><i class="fab fa-facebook-f"></i></a>
    <a class="w-50 h-50 lh-50 rounded-circle float-left text-black hover:bg-gray-100 share-page__on-linkedin"><i class="fab fa-linkedin-in"></i></a>
    <a class="w-50 h-50 lh-50 rounded-circle float-left text-black hover:bg-gray-100 share-page__on-twitter"><i class="fab fa-twitter"></i></a>
    <a class="w-50 h-50 lh-50 rounded-circle float-left text-black hover:bg-gray-100" href="whatsapp://send?text=<?php the_title();?> <?php the_permalink();?>"><i class="fab fa-whatsapp color_black"></i></a>
</div>