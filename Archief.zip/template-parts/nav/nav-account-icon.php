<a href="/my-account" class="position-absolute top-0 right-60 right-lg-0 position-lg-relative ml-lg-20">
<svg class="w-20 h-20 position-relative top-10 text-black hover:text-tertiary" id="Laag_1" data-name="Laag 1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
  <path d="M256,32A112,112,0,1,1,144,144,112.07,112.07,0,0,1,256,32M384,352a96.15,96.15,0,0,1,96,96v32H32V448a96.15,96.15,0,0,1,96-96H384M256,0A144,144,0,1,0,400,144,144,144,0,0,0,256,0ZM384,320H128A128,128,0,0,0,0,448v32a32,32,0,0,0,32,32H480a32,32,0,0,0,32-32V448A128,128,0,0,0,384,320Z" transform="translate(0 0)"/>
</svg>
</a>