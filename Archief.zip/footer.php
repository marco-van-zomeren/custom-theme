<footer class="bg-white row p-20 p-md-40"> 
  
  <!-- FOOTER COLUMN -->
  <div class="col-12 col-md-3">
    <p class="font-weight-700 text-transform-uppercase d-table text-black "> 
		<i class="material-icons d-table-cell align-middle d-block d-md-none"> 
		keyboard_arrow_down
		 </i> 
		<span class="d-table-cell align-middle">
      <?php
      $locations = get_nav_menu_locations(); //get all menu locations
      $menu = wp_get_nav_menu_object( $locations[ 'footer-menu-1' ] ); //get the menu object

      echo $menu->name; // name of the menu
      ?>
      </span> 
	 </p>
    <?php wp_nav_menu( array( 
	'theme_location' => 'footer-menu-1',
	'container'=> false, 
	'menu_class'=> 'd-none d-md-block c:text-black',
	'add_li_class'  => 'py-10'   
)) ?>
  </div>
  <!-- --> 
  <!-- FOOTER COLUMN -->
  <div class="col-12 col-md-3">
    <p class="font-weight-700 text-transform-uppercase d-table text-black "> 
		<i class="material-icons d-table-cell align-middle d-block d-md-none"> 
		keyboard_arrow_down
		 </i> 
		<span class="d-table-cell align-middle">
      <?php
      $locations = get_nav_menu_locations(); //get all menu locations
      $menu = wp_get_nav_menu_object( $locations[ 'footer-menu-1' ] ); //get the menu object

      echo $menu->name; // name of the menu
      ?>
      </span> 
	 </p>
    <?php wp_nav_menu( array( 
	'theme_location' => 'footer-menu-1',
	'container'=> false, 
	'menu_class'=> 'd-none d-md-block c:text-black',
	'add_li_class'  => 'py-10'   
)) ?>
  </div>
  <!-- --> 	

  
</footer>
<?php wp_footer(); ?>
<script src="<?php bloginfo('template_url'); ?>/js/script.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>  
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
</body>
</html>